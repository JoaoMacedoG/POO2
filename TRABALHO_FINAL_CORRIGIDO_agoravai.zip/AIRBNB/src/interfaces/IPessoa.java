package interfaces;

public interface IPessoa {
	public String getSexo();
	public void setSexo(String sexo);
	public int getCpf();
	public void setCpf(int cpf);
	public String getNome();
	public void setNome(String nome);

}
