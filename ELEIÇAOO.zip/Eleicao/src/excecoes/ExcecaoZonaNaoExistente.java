package excecoes;

public class ExcecaoZonaNaoExistente extends Exception{
		
		
			
			private static final long serialVersionUID =1L;
			
			
			public ExcecaoZonaNaoExistente(){
				super();
			}

			public ExcecaoZonaNaoExistente(String msg){
				super(msg);
			}
		}


