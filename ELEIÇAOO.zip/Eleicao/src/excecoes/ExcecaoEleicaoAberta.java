package excecoes;

public class ExcecaoEleicaoAberta  extends Exception{
	private static final long serialVersionUID =  1L;

	
	public ExcecaoEleicaoAberta(){
		super();
	}

	public ExcecaoEleicaoAberta(String msg){
		super(msg);
	}

}
