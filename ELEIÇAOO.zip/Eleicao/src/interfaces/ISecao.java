package interfaces;

public interface ISecao {
	public int getNumeroSecao();
	public IZonaEleitoral getZona();

}
