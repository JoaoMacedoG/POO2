package interfaces;

public interface ICidade {
	public String getNomeCidade();
	public void setNomeCidade(String nomeCidade);
	

}
