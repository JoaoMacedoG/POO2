package testes;

import java.io.FileNotFoundException;

import org.junit.Before;
import org.junit.Test;

import excecoes.ImovelNaoExiste;
import modelo.FachadaAIRBNB;

public class TesteAvaliaImovel {

	private FachadaAIRBNB projeto;

	@Before
	public void configura() throws FileNotFoundException {

		projeto = new FachadaAIRBNB();

	}

	@Test
	public void avaliarImovel() throws ImovelNaoExiste {

		projeto.avaliarImovel(projeto.getImovel("ap"), 10);
		projeto.avaliarImovel(projeto.getImovel("ap"), 10);

		//assertEquals(1, projeto.getImovel("ap").getNotaDoImovel());

		System.out.println(projeto.getImovel("ap").getNotaDoImovel());
	}

}
