package modelo.Comparadores;

import java.io.Serializable;

import modelo.FachadaAIRBNB;
import modelo.Reserva;

public class ComparadorReserva implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private FachadaAIRBNB fachada;

	public ComparadorReserva(FachadaAIRBNB fachada) {
		this.fachada = fachada;
	}

	public boolean checaSeReservado(Reserva reserva) {

		for (int cont = 0; cont < fachada.tamanhoListReservas(); cont++) {
			if (comparaMesmoNomeCidade(reserva, cont) && comparaNomeImovelEscolhido(reserva, cont)
					&& comparaDataEntrada(reserva, cont) && comparaDataSaida(reserva, cont)
					&& comparaMesmoMes(reserva, cont)) {

				return true;
			}
		}
		return false;
	}

	private boolean comparaMesmoMes(Reserva reserva, int cont) {
		if (fachada.getReservas().get(cont).getMes() == reserva.getMes()) {
			return true;
		}
		return false;
	}

	private boolean comparaDataSaida(Reserva reserva, int cont) {
		if (reserva.getDataDeSaida() <= fachada.getReservas().get(cont).getDataDeSaida()) {
			return true;
		}
		return false;
	}

	private boolean comparaDataEntrada(Reserva reserva, int cont) {
		if (reserva.getDataDeInicio() >= fachada.getReservas().get(cont).getDataDeInicio()) {
			return true;
		}
		return false;
	}

	private boolean comparaNomeImovelEscolhido(Reserva reserva, int cont) {
		if (fachada.getReservas().get(cont).getImovelEscolhido().getNomeImovel()
				.equals(reserva.getImovelEscolhido().getNomeImovel())) {
			return true;
		}
		return false;
	}

	private boolean comparaMesmoNomeCidade(Reserva reserva, int cont) {

		if (fachada.getReservas().get(cont).getCidade().getNomeCidade().equals(reserva.getCidade().getNomeCidade())) {
			return true;
		}

		return false;
	}

}
