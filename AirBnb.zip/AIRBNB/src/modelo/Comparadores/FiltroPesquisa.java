package modelo.Comparadores;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import modelo.FachadaAIRBNB;
import modelo.Imovel;
import modelo.Filtro.Filtro;

public class FiltroPesquisa implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private FachadaAIRBNB fachada;

	public List<Imovel> filtrar(Filtro filtro) {

		fachada = FachadaAIRBNB.getInstance();
		List<Imovel> imoveisFiltrados = new ArrayList<Imovel>();

		for (int i = 0; i < fachada.tamanhoListImoveis(); i++) {
			if (fachada.getImoveis().get(i).getNumeroBanheiros() == filtro.getNumeroBanheiros()
					&& fachada.getImoveis().get(i).getNumeroCamas() == filtro.getNumeroCamas()
					&& fachada.getImoveis().get(i).getNumeroQuartos() == filtro.getNumeroQuartos()
					&& fachada.getImoveis().get(i).getCidade().getNomeCidade().equals(filtro.getCidade())
					&& fachada.getImoveis().get(i).getPreco() >= filtro.getPrecoMinimo()
					&& fachada.getImoveis().get(i).getPreco() <= filtro.getPrecoMaximo()) {
				imoveisFiltrados.add(fachada.getImoveis().get(i));
			} else {
				i++;
			}
			;
		}
		return imoveisFiltrados;

	}

}
