package modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import excecoes.ExcecaoCidadeExistente;
import excecoes.ExcecaoImovelExistente;
import excecoes.ExcecaoPessoaExistente;
import excecoes.ImovelJaReservado;
import excecoes.ImovelNaoEncontrado;
import excecoes.ImovelNaoExiste;
import excecoes.ReservaNaoExistente;
import interfaces.IFachadaAirBNB;
import modelo.Imovel;
import modelo.Comparadores.ComparadorReserva;
import modelo.Comparadores.FiltroPesquisa;
import modelo.Criador.CriadorDeCidades;
import modelo.Filtro.Filtro;

public class FachadaAIRBNB extends CriadorDeCidades implements IFachadaAirBNB, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer armazenaNotaParaM�dia= 0;
	private List<Reserva> reservas;
	private List<Imovel> imoveis;
	private List<Cidade> cidades;
	private List<Pessoa> pessoas;
	private static FachadaAIRBNB singleton;

	public FachadaAIRBNB() {
		
		this.cidades = new ArrayList<Cidade>();
		this.imoveis = new ArrayList<Imovel>();
		this.pessoas = new ArrayList<Pessoa>();
		this.reservas = new ArrayList<Reserva>();
		criaImoveis();
		criaCidades();
		
	}

	public static FachadaAIRBNB getInstance() {
		if (singleton == null)
			singleton = new FachadaAIRBNB();
		return singleton;
	}

	public int tamanhoListPessoas() {
		return pessoas.size();
	}

	public int tamanhoListImoveis() {
		return imoveis.size();
	}

	public int tamanhoListReservas() {
		return reservas.size();
	}

	public int tamanhoListCidades() {
		return cidades.size();
	}

	public List<Reserva> getReservas() {
		return reservas;
	}

	public List<Imovel> getImoveis() {
		return imoveis;
	}

	public void setImoveis(List<Imovel> imoveis) {
		this.imoveis = imoveis;
	}

	public List<Cidade> getCidades() {
		return cidades;
	}

	public void setCidades(List<Cidade> cidades) {
		this.cidades = cidades;
	}

	@Override
	public List<Imovel> pesquisarImovel(Filtro filtro) throws ImovelNaoEncontrado {
		FiltroPesquisa filtrador = new FiltroPesquisa();
		List<Imovel> imoveisFiltrados = filtrador.filtrar(filtro);
		if(imoveisFiltrados == null){
			throw new ImovelNaoEncontrado();
		}
		return imoveisFiltrados;

	}

	private void aumentaAvaliacoesImovel(Imovel imovel) {
		Integer avaliacoes = imovel.getNumeroAvaliacoes() + 1;
		imovel.setNumeroAvaliacoes(avaliacoes);
	}

	@Override
	public void avaliarImovel(Imovel imovel, Integer avaliar) throws ImovelNaoExiste {
		armazenaNotaParaM�dia = armazenaNotaParaM�dia + avaliar;
		aumentaAvaliacoesImovel(imovel);
		Integer media = armazenaNotaParaM�dia / (imovel.getNumeroAvaliacoes());
		imovel.setNotaDoImovel(media);
	}

	@Override
	public void reservarImovel(Reserva reserva) throws ImovelNaoExiste, ImovelJaReservado {
		ComparadorReserva comparador = new ComparadorReserva(this);
		if (getReserva(reserva.getIdReserva()) == null && comparador.checaSeReservado(reserva) == false) {
			reservas.add(reserva);
			
		}else{
			throw new ImovelJaReservado();
		}
	}

	public void criaImoveis() {
		this.imoveis.addAll(criaListImoveis());
	}
	
	public void cancelarReserva(Integer cpf) throws ReservaNaoExistente{
		for(int i=0; i<reservas.size();i++){
			Reserva reserva= this.reservas.get(i);
			if(reserva.getPessoa().getCpf() == cpf){
				reservas.remove(reserva);
			}else{
				throw new ReservaNaoExistente();
			}
		}
	}

	public List<Pessoa> getPessoas() {
		return pessoas;
	}

	public void criaCidades() {
		this.cidades.addAll(criaListCidades());
		
	}

	public Pessoa getPessoa(int cpf) {

		for (int cont = 0; cont < this.pessoas.size(); cont++) {
			Pessoa pessoa = this.pessoas.get(cont);
			if (pessoa.getCpf() == cpf) {
				return pessoa;
			}
		}
		return null;
	}

	public Reserva getReserva(Integer cpf) {
		for (int cont = 0; cont < this.reservas.size(); cont++) {
			Reserva reserva = this.reservas.get(cont);
			if (reserva.getPessoa().getCpf() == cpf) {
				return reserva;
			}
		}
		return null;
	}

	public Imovel getImovel(String nomeImovel) {
		for (int cont = 0; cont < this.imoveis.size(); cont++) {
			Imovel imovel = this.imoveis.get(cont);
			if (imovel.getNomeImovel().equals(nomeImovel)) {
				return imovel;
			}
		}
		return null;
	}

	public Cidade getCidade(String nomeCidade) {
		for (int cont = 0; cont < this.cidades.size(); cont++) {
			Cidade cidade = this.cidades.get(cont);
			if (cidade.getNomeCidade().equals(nomeCidade)) {
				return cidade;
			}
		}
		return null;
	}

	public void cadastraPessoa(String nome, String sexo, int cpf) throws ExcecaoPessoaExistente {
		Pessoa checarSePessoaNull = getPessoa(cpf);
		if (checarSePessoaNull == null) {
			checarSePessoaNull = new Pessoa(nome, sexo, cpf);
			this.pessoas.add(checarSePessoaNull);
		} else {
			throw new ExcecaoPessoaExistente();
		}

	}
	
	public void criaCidadeSeNaoExiste(String nomeCidade) throws ExcecaoCidadeExistente{
		Cidade checaSeExiste = getCidade(nomeCidade);
		if(checaSeExiste == null){
			checaSeExiste = new Cidade(nomeCidade);
			this.cidades.add(checaSeExiste);
		} else{
			throw new ExcecaoCidadeExistente();
		}
	}

	public void cadastraImovel(String cidade, String nomeImovel, Integer numeroDeBanheiros, Integer numeroCamas,
			Integer numeroQuartos, double preco) throws ExcecaoImovelExistente, ExcecaoCidadeExistente {
		Imovel checarSeImovelNull = getImovel(nomeImovel);
		criaCidadeSeNaoExiste(cidade);
		if (checarSeImovelNull == null) {
			checarSeImovelNull = new Imovel(getCidade(cidade), nomeImovel, numeroDeBanheiros, numeroCamas,
					numeroQuartos, preco, 0);
			this.imoveis.add(checarSeImovelNull);
		} else {
			throw new ExcecaoImovelExistente();
		}

	}





	
	}


